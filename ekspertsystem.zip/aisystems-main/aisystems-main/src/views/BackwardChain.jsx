import { useState } from 'react';
import leaf from "../assets/golden.jpg";
import backward from "../assets/backward.jpg";

export default function BackwardChain() {

  // Knowledge base
  const [facts, setFacts] = useState({
    large: null,
    active: null,
  });

  // User Interface (UI)
  const askQuestion = (fact) => {
    return (
      <div key={fact}>
        <p>Do you prefer a {fact.replace('_', ' ')} dog?</p>
        <button onClick={() => setFacts({ ...facts, [fact]: "Yes" })}>Yes</button>
        <button onClick={() => setFacts({ ...facts, [fact]: "No" })}>No</button>
      </div>
    );
  };

  // Inference engine
  const backwardChain = (goal) => {
    let conclusions = [];

    if (goal === 'golden_retriever') {

      if (facts.large === null) {
        return askQuestion('large');
      }
      conclusions.push(`Large: ${facts.large}`);

      if (facts.active === null && facts.large === "Yes") {
        return askQuestion('active');
      }
      conclusions.push(`Active: ${facts.active}`);

      if (facts.large=="Yes" && facts.active==="No") {
        return (
          <div>
            <p>CONCLUSION: A Golden Retriever is a great fit for you!</p>
            <p>Based on the facts:</p>
            <ul>
              {conclusions.map((fact, index) => fact.includes('null') ? null : (
              <li key={index}>{fact}</li>
              ))}
            </ul>
          </div>
        );
      } 
    }

    // If criteria is not met, show this
      return (
        <div>
          <p>CONCLUSION: A Golden Retriever may not be the best choice for you.</p>
          <p>Based on the facts:</p>
          <ul>
            {conclusions.map((fact, index) => fact.includes('null') ? null : (
              <li key={index}>{fact}</li>
            ))}
          </ul>
        </div>
      );
  };

  // This is the "diagnosis" that can be confirmed:
  const goal = 'golden_retriever';

  return (
    <div>
      <h1>Backward Chaining: Dog Breed Recommendation</h1>
      <p>Is a <span style={{ backgroundColor: "yellow" }}>{goal.replace('_', ' ')}</span> the right dog for you?</p>
      {backwardChain(goal)}
      <img src={leaf} alt="image" style={{marginTop: "25px", width: "250px"}}/>
      <img src={backward} alt="image" style={{marginTop: "25px", display: "block"}}/>
    </div>
  );
}
