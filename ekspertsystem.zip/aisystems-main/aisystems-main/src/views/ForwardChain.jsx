import { useState } from 'react';
import leaf from "../assets/lillehund.png";
import forward from "../assets/forward.jpg";

export default function ForwardChain() {

  // Knowledge base
  const [facts, setFacts] = useState({
    active: null,
    small: null,
  });

  // User Interface (UI)
  const askQuestion = (fact) => {
    return (
      <div key={fact}>
        <p>Do you prefer a {fact.replace('_', ' ')} dog?</p>
        <button onClick={() => setFacts({ ...facts, [fact]: "Yes" })}>Yes</button>
        <button onClick={() => setFacts({ ...facts, [fact]: "No" })}>No</button>
      </div>
    );
  };

  // Inference engine
  const forwardChain = () => {
    if (facts.active === null) {
      return askQuestion('active');
    }

    if (facts.small === null) {
      return askQuestion('small');
    }

    let recommendation = '';
    let conclusion = 'Based on the preferences: ';

    if (facts.active==="Yes" && facts.small==="Yes") {
      recommendation = 'A small, energetic dog like a Jack Russell Terrier would be a great fit for you!';
      conclusion += 'you prefer small and active dogs.';
    } else if (facts.active==="No" && facts.small==="No") {
      recommendation = 'A large, calm dog like a Golden Retriever would be a great fit for you!';
      conclusion += 'you prefer large and calm dogs.';
    } else if (facts.active==="Yes" && facts.small==="No") {
      recommendation = 'A large, active dog like a Border Collie would be a great fit for you!';
      conclusion += 'you prefer large and active dogs.';
    } else if (facts.active==="No" && facts.small==="Yes") {
      recommendation = 'A small, calm dog like a Cavalier King Charles Spaniel would be a great fit for you!';
      conclusion += 'you prefer small and calm dogs.';
    }

    return (
      <div>
        <p>{recommendation}</p>
        <p>{conclusion}</p>
      </div>
    );
  };

  return (
    <div>
      <h1>Forward Chaining: Your dog preferences</h1>
      {forwardChain()}
      <img src={leaf} alt="image" style={{marginTop: "25px",width: "250px"}}/>
      <img src={forward} alt="image" style={{marginTop: "25px",display: "block"}}/>
    </div>
  );
}
