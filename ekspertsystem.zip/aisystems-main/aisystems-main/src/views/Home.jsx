export default function Home() {
    return (
        <h2>Try out the different AI tools in the menu</h2>
    )

}